package rev.exe;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.HashMap;
import java.util.Map;

/** All settings in one key -> float map (booleans are 0/1, choices are indexes). ESP/radar only: no aim/weapon
 *  offsets were confirmed for this dump, so none of that config exists here (nothing to fake). */
final class Cfg {
    static final HashMap<String, Float> DEF = new HashMap<>();
    static final HashMap<String, Float> V = new HashMap<>();
    static final int[] COL = {0xFFFF4A3D, 0xFFFF9F1A, 0xFF4ADE80, 0xFF5AB0FF, 0xFFFFFFFF};
    static String pkg = "oxide";

    private static void d(String k, float v) { DEF.put(k, v); }

    static {
        d("esp", 1); d("name", 1); d("dist", 1); d("radar", 1); d("radarRange", 120); d("radarSize", 140);
        d("hideFriend", 0); d("hideTeam", 0); d("maxDist", 400); d("sortNear", 1);
        d("enemyCol", 0); d("friendCol", 2); d("teamCol", 3);
        V.putAll(DEF);
    }

    static float f(String k) { Float v = V.get(k); return v == null ? 0f : v; }
    static boolean b(String k) { return f(k) >= 0.5f; }
    static int i(String k) { return Math.round(f(k)); }
    static void set(String k, float v) { V.put(k, v); }
    static int col(String k) { return COL[Math.max(0, Math.min(COL.length - 1, i(k)))]; }

    static void reset() { V.clear(); V.putAll(DEF); }

    private static SharedPreferences sp(Context c) { return c.getSharedPreferences("revolt", Context.MODE_PRIVATE); }

    static void load(Context c) {
        SharedPreferences p = sp(c);
        for (Map.Entry<String, Float> e : DEF.entrySet()) V.put(e.getKey(), p.getFloat(e.getKey(), e.getValue()));
        pkg = p.getString("pkg", pkg);
    }

    static void save(Context c) {
        SharedPreferences.Editor ed = sp(c).edit();
        for (Map.Entry<String, Float> e : V.entrySet()) ed.putFloat(e.getKey(), e.getValue());
        ed.putString("pkg", pkg).apply();
    }
}
