// OxideRevolution offsets, from bd36c989-imguisource_bot_2.zip (dump.cs). Mirror-netcode build, namespaces blanked by obfuscator.
// TypeInfo RVAs NOT extracted from script.json yet -> 0, Il2::klass() falls back to its heap/name scan (slower first hit, same result).
#pragma once
#include <cstdint>

struct ClassRef { const char* ns; const char* name; uint64_t typeinfo_rva; };

namespace off {

namespace NetworkBehaviour {              // `vd : MonoBehaviour`, TypeDefIndex 21392 (renamed Mirror.NetworkBehaviour)
  constexpr ClassRef cls = {"", "vd", 0};
  constexpr uint32_t netIdentity = 0x40;  // backing field; object size 0x78
}

namespace NetworkIdentity {               // Mirror.NetworkIdentity, class name preserved
  constexpr ClassRef cls = {"", "NetworkIdentity", 0};
  constexpr uint32_t isOwned = 0x25;      // bool -- positional match vs. prior unobfuscated dump of the same Mirror class
  constexpr uint32_t netId   = 0x30;      // uint
}

namespace PlayerManager {                 // PlayerManager : vd, TypeDefIndex 2879
  constexpr ClassRef cls = {"", "PlayerManager", 0};
  constexpr uint32_t worldCameraRoot = 0x80;  // Transform*
  constexpr uint32_t vitals          = 0xC8;  // PlayerVitals* (hp has no flat backing field -- not read)
  constexpr uint32_t team            = 0x120; // Lh*
  constexpr uint32_t nicklabel       = 0x130; // Yd*
}

namespace Yd {                            // nametag component
  constexpr ClassRef cls = {"", "Yd", 0};
  constexpr uint32_t nickname   = 0x38;   // UnityEngine.UI.Text*
  constexpr uint32_t isFriend   = 0x88;   // bool
  constexpr uint32_t isTeammate = 0x89;   // bool
}

namespace UIText {                        // UnityEngine.UI.Text (stock)
  constexpr ClassRef cls = {"UnityEngine.UI", "Text", 0};
  constexpr uint32_t m_Text = 0xE0;       // System.String*
}

} // namespace off
